import CommonFunctions as common
import urllib
import urllib2
import os
import xbmcplugin
import xbmcgui
import xbmcaddon
import urlfetch
import Cookie
from xgoogle.search import GoogleSearch, SearchError
import StorageServer
import re
import time
import datetime


try:
	import json
except:
	import simplejson as json

__settings__ = xbmcaddon.Addon(id='plugin.video.fsrepo')
__language__ = __settings__.getLocalizedString
home = __settings__.getAddonInfo('path')
icon = xbmc.translatePath( os.path.join( home, 'icon.png' ) )
saveSearch = 'false'
email = __settings__.getSetting('email')

#if saveSearch=='true':
cache = StorageServer.StorageServer("fshare3")
mid   = cache.get('mid') 
if not mid :
	mid = int(time.time())
	cache.set('mid', str(mid))

HTTP_DESKTOP_UA = {
	'Host':'www.fshare.vn',
	'Accept-Encoding':'gzip, deflate',
	'Referer':'https://www.fshare.vn/',
	'Connection':'keep-alive',
	'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'User-Agent':'Mozilla/5.0 (Windows NT 6.2; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0'
}

searchList=[]
headers = HTTP_DESKTOP_UA

def _makeCookieHeader(cookie):
	cookieHeader = ""
	for value in cookie.values():
		cookieHeader += "%s=%s; " % (value.key, value.value)
	return cookieHeader

def doLogin():

	username = __settings__.getSetting('username')
	password = __settings__.getSetting('password')
	if (not username) or (not password):
		return False
	cookie = Cookie.SimpleCookie()
	response = urlfetch.fetch('https://www.fshare.vn')

	cookie.load(response.headers.get('set-cookie', ''))
	items = re.compile('value=\"(.+?)\" name=\"fs_csrf\"', re.DOTALL).findall(response.content)

	#print items[0]

	form_fields = {
		"fs_csrf" : items[0],
		"LoginForm[email]":  username,
		"LoginForm[password]":  password,
#		"url_refe": "https://www.fshare.vn/index.php"
		"LoginForm[rememberMe]" : "0",
		"yt0": "%C4%90%C4%83ng+nh%E1%BA%ADp"
	}

	form_data = urllib.urlencode(form_fields)
	#print form_data
	headers['Cookie'] = _makeCookieHeader(cookie)
	print headers['Cookie']
	response = urlfetch.fetch(
		url = 'https://www.fshare.vn/login',
		method='POST',
		headers = headers,
		data=form_data,
		follow_redirects = False
	)

	items = re.compile('<title>(.+?)</title>', re.DOTALL).findall(response.content)
	if items:
		if (items[0]=='400'):
			xbmc.executebuiltin((u'XBMC.Notification("%s", "%s", %s)' % ('Login', 'Login failed. You must input correct FShare username/pass in Add-on settings', '15')).encode("utf-8"))	 
			return False
		else:
			print 'dologin res code: '+items[0]
	else:
		print str(response.status)+response.content

	#print 'dologin '+response.content
	cookie.load(response.headers.get('set-cookie', ''))
	headers['Cookie'] = _makeCookieHeader(cookie)

	if headers['Cookie'].find('-1')>0:
		xbmc.executebuiltin((u'XBMC.Notification("%s", "%s", %s)' % ('Login', 'Login failed. You must input correct FShare username/pass in Add-on settings', '15')).encode("utf-8"))	 
		return False
	else:
		cache.set('cookie', headers['Cookie'])
		return headers['Cookie']
	
def make_request(url):
	headers = {
		'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'User-Agent':'Mozilla/5.0 (Windows NT 6.2; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0'
	}
	try:
		req = urllib2.Request(url,headers=headers)
		f = urllib2.urlopen(req)
		body=f.read()
		return body
	except urllib2.URLError, e:
		print 'We failed to open "%s".' % url
		if hasattr(e, 'reason'):
			print 'We failed to reach a server.'
			print 'Reason: ', e.reason
		if hasattr(e, 'code'):
			print 'We failed with error code - %s.' % e.code


def get_categories():
	add_dir(u'Phim Xem Nhi\u1EC1u Nh\u1EA5t'.encode('utf8'), '', 24, '', 'root')
	add_dir(u'Phim L\u1EBB'.encode('utf8'), 'http://vaphim.com/category/phim-2/phim-le/', 25, 'root')
	add_dir(u'Phim B\u1ED9 H\u00E0n'.encode('utf8'), 'http://vaphim.com/category/phim-2/series/korean-series/', 25, 'root')
	add_dir(u'Phim B\u1ED9 H\u1ED3ng K\u00F4ng'.encode('utf8'), 'http://vaphim.com/category/phim-2/series/hongkong-series/', 25, 'root')
	add_dir(u'Phim B\u1ED9'.encode('utf8'), 'http://vaphim.com/category/phim-2/series/', 25, 'root')
	
	add_dir(u'Phim Ho\u1EA1t H\u00ECnh'.encode('utf8'), 'http://vaphim.com/category/phim-2/animation/', 25, 'root')

	add_dir('Search VAPhim', url, 2, '', '', 'vaphim', 0)
	add_dir('LSFilm', '', 20, '', 'root')
	add_dir('Play Fshare URL', '', 21, '', 'root')
	if saveSearch=='true':
		add_dir('Search Google', '', 1, '', query, 'google', 0)
		#add_dir('Search HDrepo', '', 1, '', query, 'hdrepo', 0)
	else:
		add_dir('Search Google', url, 2, '', '', 'google', 0)

	#add_dir('Search HDrepo', url, 2, '', '', 'hdrepo', 0)
	#add_dir('Apple iTunes', 'apple_root', 14, icon, '', 'folder', 0)

	add_dir('Add-on settings', '', 10, icon, query, type, 0)

def addPlayURL(url):
	print url
	if 'folder' in url:
		add_fshareDir('', url)
	else:
		response = urlfetch.fetch(url)
		#print response.content
		#regterm = u'T\u00EAn\ t\u1EADp\ tin:</b>\s(.+?)</p>.+?</b>\s(.+?)</p>'.encode('utf8')
		#regterm = u'class=\"file\" title=\"(.+?)\".+?class=\"capital\".+?<td>([0-9.K\sMGB]+?)</td>'.encode('utf8')
		regterm = u'class=\"file-info\">.+?</i>(.+?)</div>.+?</i>(.+?)</div>'.encode('utf8')
		#print regterm
		item = re.findall(regterm, response.content, re.DOTALL|re.MULTILINE)
		print item
		if (item):
			name = item[0][0].strip()+' '+item[0][1].strip()
			print item[0][1]
			y = item[0][0].strip().rpartition('.')
			if (not(y[2] in ['jpg', 'png', 'txt', 'torrent', 'nfo', 'srt', 'sub', 'rar', 'zip', 'iso', 'ts', 'vob'])):
				#print y[2]+' exception1'
				add_link('', name, '', url, '', name)

def getParamNoEx(items, key):
	try:
		return items[key]
	except:
		return ''


def vaphimSearch(query, page=0):
	response = urlfetch.fetch('http://vaphim.com/?s='+query)
	rows = re.compile("<a data=.+?<img.+?src=\"(.+?)\".+?<a href=\"(http://vaphim.com/.+?)\".+?>(.+?)</a>", re.DOTALL).findall(response.content)
	for item in rows:
		name = re.sub(r'<.+?>', r'-', item[2])
		add_dir(name, item[1], 22, item[0], '', '', '')

def vaphimPage(url):
	response = urlfetch.fetch(url)
	regterm = u'N\u0103m s\u1EA3n xu\u1EA5t: </b>(.+?)<.+?/b>([^<]+?)<.+?<a href=\"(.+?)\"'.encode('utf8')
	#print regterm
	info = re.search(regterm, response.content, re.DOTALL|re.MULTILINE)

	date =2000
	length = 60
	thumbnail =''
	if info:
		print info
		if info.group(1) != 'N/A':
			date = info.group(1)
		if info.group(2) != 'N/A':
			r = info.group(2).split()
			print r
			if (len(r)==4):
				length =int(r[0])*60+int(r[2])
			else:
				length = int(r[0])
			print length
		thumbnail = info.group(3)
	else:
		info = re.search('<div id=\"attachment.+?<a href=\"(.+?)\"', response.content, re.DOTALL|re.MULTILINE)
		if info:
			thumbnail = info.group(1)

	rows = re.compile("<a [/s]*?href=\"(http[s]*://www.fshare.vn/f.+?)\".+?>(.+?)</a>", re.DOTALL).findall(response.content)
	for item in rows:
		print item[1]
		name = re.sub(r'<.+?>', r'', item[1])
		print name
		name = name.lstrip(' ')
		if (name != u'Ph\u1EE5 \u0110\u1EC1 Vi\u1EC7t'.encode('utf8')) and (name != u'Ph\u1EE5 \u0111\u1EC1 Vi\u1EC7t'.encode('utf8')):
			if 'folder' in item[0]:
				add_fshareDir(name, item[0])
			else:
				add_link(date, name, length, item[0], thumbnail, name)

def vaphimCategory(url):
	print 'load va folder cat'
	response = urlfetch.fetch(url)
	rows = re.compile("class=\"entry-thu.+?<img.+?src=\"(.+?)\".+?<a href=\"(.+?)\".+?>(.+?)<", re.DOTALL).findall(response.content)
	for item in rows:
		name = re.sub(r'<.+?>', r'-', item[2])
		add_dir(name, item[1], 22, item[0], '', '', '')
	#<a href='http://vaphim.com/category/phim-le/' class='previouspostslink'>
	rows = re.compile("a href=\'([^\']+?)\' class=\'nextpostslink\'", re.DOTALL).findall(response.content)
	if rows:
		add_dir('Next>', rows[0], 25, '', '', '', '')
	rows = re.compile("a href=\'([^\']+?)\' class=\'previouspostslink\'", re.DOTALL).findall(response.content)
	if rows:
		add_dir('Prev>', rows[0], 25, '', '', '', '')


def vaphimXemNhieu():
	response = urlfetch.fetch('http://vaphim.com')
	rows = re.compile("class=\"widgettitle\">Xem nh(.+?)</ul>", re.DOTALL).search(response.content)
	if rows:
		#print rows.group(0)
		items = re.compile("li><a href=\"(.+?)\".+?>(.+?)</a", re.DOTALL).findall(rows.group(1))
		for item in items:
			name = re.sub(r'<.+?>', r'-', item[1])
			add_dir(name, item[0], 22, '', '', '', '')

def fsrepo(provider, param, start=0):
	data = {'param': param, 'start': start}
	data = urllib.urlencode(data)
	response = urllib.urlopen('https://script.google.com/macros/s/AKfycbzGCHXLcvp_993yFFCxV-XK1sdgcBI2sgmjOIOlyWVzNXAghFo/exec', data)
	print response
	result = json.load(response)
	#print result
	for item in result:
		try:
			_type = item['type']
			_title = item['title']
			_param = item['param']
		except:
			continue
		_title = _title.encode('utf8', 'ignore')
		_thumb = getParamNoEx(item, 'thumb')
		_date = getParamNoEx(item, 'date')
		_duration = getParamNoEx(item, 'duration')

		if (_type == 'fshare_folder'):
			add_dir(_title+' >', _param, 16, _thumb, '', '', 'fshare_folder')
		elif _type == 'fshare_file':
			add_link(_date, _title, _duration, _param, _thumb, _title)
		elif _type == 'fsrepo':
			#print _title
			add_dir(_title+' >', '', 20, _thumb, _param)
		elif _type == 'thiendia':
			add_dir(_title+' >', _param, 26, _thumb, _param)
		elif _type == 'thiendia_folder':
			add_dir(_title+' >', _param, 27, _thumb, _param) 

def thiendia_folder(provider, param, start=0):
	response = urlfetch.fetch(param,
	headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.2; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0'})
	rows = re.compile('<!-- show threads -->(.+?)End Active Users in this Forum', re.DOTALL).findall(response.content)
	print 'load '+param
	#print str(response.status_code)+' '+str(len(response.content))
	if rows:
		#print rows[0]
		trs = re.compile('<a href=\"(showthread\.php\?t=[0-9]+?)\" [^>]+?>([^<]+?)<', re.DOTALL).findall(rows[0])
		for tr in trs:
			if '[4share]' in tr[1].lower():
				continue
			add_dir(tr[1]+'>', 'http://thiendia.com/diendan/'+tr[0], 26, '', '')
		nav=re.compile('<a rel=\"next\" class=\"smallfont\" href=\"(forumdisplay\.php\?f=[^\"]+?)\"', re.DOTALL).findall(response.content)
		if nav:
			add_dir('Next>', 'http://thiendia.com/diendan/'+nav[0], 27, '', '')
			print 'found next link '+nav[0]
		nav=re.compile('<a rel=\"prev\" class=\"smallfont\" href=\"(forumdisplay\.php\?f=[^\"]+?)\"', re.DOTALL).findall(response.content)
		if nav:
			add_dir('Prev>', 'http://thiendia.com/diendan/'+nav[0], 27, '', '')
			print 'found prev link'+nav[0]
		else:
			print 'prev link not found'
def iterTag(input, tag, tagwithatt):
	length=len(input)
	idx = 0
	level =0
	resultset = []
	start = -1
	end = -1
	stag = -1
	etag = -1
	tg=''
	_tgwithatt =''
	attlen=len(tagwithatt)
	state = 0
	inc=1
	while(idx <length):
		c = input[idx]
		# if idx>4000 and idx <4200:
		# 	print str(idx)+' '+str(state)+' '+c+' '+str(etag)
		if c == '<':
			if state !=22:
				state = 1
				stag = idx+1
				inc = 1
		elif c == '/':
			if state == 1:
				state =2
				inc = -1
				stag =idx+1
		elif c == '>':
			if state ==3:
				if etag==-1:
					etag = idx
				tg = input[stag:etag]
				_tgwithatt = input[stag:stag+attlen]
				#print 'tag: '+tg+' '+str(idx)
				if tag==tg:
					if (_tgwithatt == tagwithatt and inc==1):
						level = 1
					level += inc
					#if idx <5000:
					# 	print str(idx)+'x=======>>>>>'+tg+' i='+str(inc)+' l='+str(level)+' >'+_tgwithatt+'<\r\n'
					# 	print input[idx-20:idx+20]
					# 	print '\r\n'
					if _tgwithatt == tagwithatt and inc==1:
						start = stag
						#print input[idx-20:idx+20]+str(level)
					#if idx <100000:
					#	print str(level)+' '+tg+' '+str(idx)+' '+_tgwithatt
					if level ==0 and inc == -1 and start >-1:
						resultset.append(input[start:idx])
						#print input[start:idx]
					#	if idx <100000:
					#		print str(idx)+'====================\r\n'
					#		print input[start:idx]
						start = -1
				etag = -1
				state =0
			elif state ==24:
				state = 0
		elif c ==' ' and state==3 and etag==-1:
			etag = idx
			#state = 3
		elif c == '!':
			if state ==1:
				state =20
		elif c =='-':
			if state == 20:
				state =21
			elif state == 21:
				state = 22
			elif state == 22:
				state = 23
			elif state == 23:
				state = 24
			if state==1 or state == 2:
				state = 3
		else:
			if state==1 or state == 2:
				state = 3
			elif state ==20 or state == 21:
				state = 1
		idx +=1
	return resultset




def thiendia(provider, param, start=0):
	response = urlfetch.fetch(param,
		headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.2; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0'})
	
	rows = re.compile(u"<div id=\"posts\">(.+?)<form action=\"postings.php", re.DOTALL).findall(response.content.decode('utf8', 'ignore'))
	#print response.status_code

	if rows:
		#print 'rows '+str(len(rows[0]))+'\r\n'
		#print rows[0][4000:5000].encode('utf8')
		#print '================================\r\n'
		trs =  iterTag(rows[0], 'div', 'div id=\"post_message')
		#trs = re.compile("<tr[^>]*?>(.+?)</tr>", re.DOTALL).findall(rows[0])
		for tr in trs:
			#print tr
			#print 'after tr===============\r\n'
			#td = re.compile("<div id=\"post[^>]+?>(.+?)</div>", re.DOTALL).findall(tr)
			td=tr
			if tr:
				title=u''
				imgurl=''
				url=''
				#print td[0]
				#print '+++++++++++++++++++++>'
				tmpt = re.sub(r"<br />", r'\n', td)
				tmpti = re.sub(r'<img src=\"([^\""]+?)"[^>]+?>', r'\nimg=\1', tmpt)
				tmpt1 = re.sub(r'<[^>]+?>', r'', tmpti).lstrip()
				#tmpt2 = re.sub('^\s*?(\n|\r\n)','', tmpt1)
				lineset = tmpt1.split('\n')
				for i in xrange(0, len(lineset), 1):
					line = lineset[i].strip().lstrip()
					if line:
						print line.encode('utf8', 'ignore')
					if ('www.fshare.vn' in line):
						if i>0:
							imgurl=''
							title=''
							for j in xrange(i-1, 0, -1):
								linej=lineset[j].strip().lstrip()
								#print str(i)+linej+'-'+str(j)+'\n'
								if linej:
									if 'img=' in linej:
										imgurl=linej[4:]
									elif imgurl <> '' and linej<>'' and 'file size' in linej.lower():
										imgurl = ''
										continue
									elif linej<>'' and imgurl<>'' and linej.lower() <> 'screenshot':
										title = lineset[j].encode('utf8', 'ignore').strip().lstrip()
										break
							url = line.encode('ascii', 'ignore')
							hpos = url.find('http')
							if hpos >0:
								url = url[hpos:]
							#print url
							if title=='':
								title=url
							#print title
							if url:
								if 'folder' in url:
									add_dir(title+'>', url, 16, imgurl, '', '', 'fshare_folder')
								else:
									add_link('', title, '', url, imgurl, title)
		#<a rel="next" class="smallfont" href="showthread.php?t=970311&amp;page=3"
		nav=re.compile('<a rel=\"next\" class=\"smallfont\" href=\"(showthread\.php\?t=[^\"]+?)\"', re.DOTALL).findall(response.content)
		if nav:
			add_dir('Next>', 'http://thiendia.com/diendan/'+nav[0], 26, '', '')
		nav=re.compile('<a rel=\"prev\" class=\"smallfont\" href=\"(showthread\.php\?t=[^\"]+?)\"', re.DOTALL).findall(response.content)
		if nav:
			add_dir('Prev>', 'http://thiendia.com/diendan/'+nav[0], 26, '', '')
def hdrepo(provider, param, start=0):
	#print 'hdrepo '+provider+' '+param
	if provider=='search':
		param = common.getUserInput('Search', '') 
		param = param.replace(' ', '%20')

	data = {'provider': provider, 'param': param, 'start': start}
	data = urllib.urlencode(data)
	response = urllib.urlopen('http://feed.hdrepo.com/v1/feed.php', data)
	result = json.load(response)
	#print result
	for item in result:
		if item['type'] == 'fshare_folder':
			#add_dir(item['title'], item['param'], 5, item['thumb'])
			add_dir(item['title'], item['provider'], 12, item['thumb'], item['param'])
		else:
			if item['type'] == 'fshare_file' and item['title'] is not None:
				add_link(item['date'], item['title'], item['duration'], item['param'], item['thumb'], item['desc'])
			else:
				if item['type'] == 'folder':
					try:
						if 'start' in item:
							add_dir(item['title'], item['provider'], 12, item['thumb'], item['param'], '', item['start'])
						else:
							add_dir(item['title'], item['provider'], 12, item['thumb'], item['param'])
					except:
						pass

def apple(provider, param, start=0):
	if provider=='apple_root':
		add_dir('Genre', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/genres.json', 'folder', 0)
		add_dir('Action and Adventure', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/action_and_adventure.json', 'folder', 0)
		add_dir('Comedy', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/comedy.json', 'folder', 0)
		add_dir('Family', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/family.json', 'folder', 0)
		add_dir('Fantasy', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/fantasy.json', 'folder', 0)
		add_dir('Foreign', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/foreign.json', 'folder', 0)
		add_dir('Horror', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/horror.json', 'folder', 0)
		add_dir('Musical', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/musical.json', 'folder', 0)
		add_dir('Romance', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/romance.json', 'folder', 0)
		add_dir('Science Fiction', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/science_fiction.json', 'folder', 0)
		add_dir('Thriller', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/thriller.json', 'folder', 0)

	if provider=='apple':
		result = json.load(urllib.urlopen(param))
		if not 'data' in result:
			movies = result;
		else:
			movies = result['data'];
		for item in movies:
			if item.get('location') is None:
				add_dir(item['title'], 'search4', 12, 'http://trailers.apple.com/' + item['poster'], item['title'])
			else:
				add_dir(item['title'], 'search4', 12, 'http://trailers.apple.com/' + item['poster'], item['title'], thumbnailImage = 'http://trailers.apple.com' + item.get('location') + 'images/background.jpg')
			#print 'http://trailers.apple.com/' + item['location'] + 'images/background.jpg';

						
def sendLink(url):
	data = {'email': email, 'url': url}
	data = urllib.urlencode(data)
	try:
		response = urllib.urlopen('http://feed.hdrepo.com/sendlink.php', data)
		result = json.load(response)
		xbmc.executebuiltin((u'XBMC.Notification("%s", "%s", %s)' % ('Download link', result['message'], '5000')).encode("utf-8"))	 
	except:
		xbmc.executebuiltin((u'XBMC.Notification("%s", "%s", %s)' % ('Download link', 'Server only accepts 1 request/minute', '5000')).encode("utf-8"))	 

def clearstring(str):
	str = ''.join(e for e in str if e.isalnum() or e in '.-_ ()')
	return str
		
def addlib(url, name):
	print 'URL' + url
	id = url
	library_folder = __settings__.getSetting('library_folder')
	if library_folder == "":
		xbmc.executebuiltin((u'XBMC.Notification("%s", "%s", %s)' % ('Add to your library', 'You need to setup library folder in Add-on Setting', '5000')).encode("utf-8"))
		return

	if not os.path.exists(library_folder):
		os.makedirs(library_folder)		
		
	if '/file/' in url:
		filename = name
		
		k = filename.rfind("(")
		k = filename.rfind(".", 0, k)
		filename = filename[:k] + '.strm'
		
		target = open (library_folder + '/' + clearstring(filename), 'w')
		target.write('plugin://plugin.video.fsrepo/?mode=4&url=' + id)
		target.close()
		return
	
	if '/folder/' in url:
		response = urlfetch.fetch(url)
		#print response.content
		rows = re.compile("\"w_80pc\"><a href=\"(.+?)\".+?class=\"filename\">(.+?)</span>.+?\"filesize\">(.+?)</span>", re.DOTALL).findall(response.content)
		library_folder = library_folder + '/' + name
		try:
			os.makedirs(library_folder)		
		except:
			pass
		for item in rows:
			filename = decodeHtmlentities(item[1])
			y = filename.rpartition('.')
			#print y[0]
			#print y[1]
			#print y[2]
			if (y[2] in ['jpg', 'png', 'txt', 'torrent', 'nfo', 'srt', 'sub', 'rar', 'zip', 'iso', 'ts', 'vob']):
				continue
			if (re.match('\.[0-9][0-9][0-9]$', filename)):
				continue
			if ' B' in item[2]:
				continue
			sfilename = y[0]+'.strm'
			#print clearstring(sfilename)
			target = open (library_folder + '/' + sfilename, 'w')
			target.write('plugin://plugin.video.fsrepo/?mode=4&url=' + item[0]+'&name='+filename)
			target.close()
		
def searchMenu(url, query = '', type='folder', page=0):
	add_dir('New Search', url, 2, '', query, type, 0)
	add_dir('Clear Search', url, 3, '', query, type, 0)

	searchList=cache.get('searchList').split("\n")
	for item in searchList:
		add_dir(item, url, 2, '', item, type, 0)

def clearSearch():
	cache.set('searchList','')

def clearCache():
	cache.delete('http%')

def gsearch(query, page=0):
	print 'gsearch called '+query+' page='+str(page)
	start = time.time()
	try:
		gs = GoogleSearch("site:fshare.vn " +query)
		gs.page = page
		gs.results_per_page = 15
		results = gs.get_results()
		for res in results:
			name = res.title.encode("utf8")
			url = res.url.encode("utf8") 
			if 'folder' in res.url:
				if name.endswith(' -- - Fshare'):
					name = name[:len(name)-12]
				#name = '>'+name
				add_dir(name+'>', url, 16, '','', 'fshare_folder')
				#add_fshareDir(name, res.url.encode('utf8'))
			else:
				print 'name='+name+" "+url+" "
				if name.startswith('Fshare - Dich vu chia se'):
					#print 'no name from google search so fetch from fshare'
					response = urlfetch.fetch(url)
					#print response.content
					regterm = u'T\u00EAn\ t\u1EADp\ tin:</b>\s(.+?)</p>.+?</b>\s(.+?)</p>'.encode('utf8')
					#print regterm
					item = re.findall(regterm, response.content, re.DOTALL|re.MULTILINE)
					print item
					if (item):
						name = item[0][0]+' '+item[0][1]
						print item[0][1]
						y = item[0][0].rpartition('.')
						if (y[2] in ['jpg', 'png', 'txt', 'torrent', 'nfo', 'srt', 'sub', 'rar', 'zip', 'iso', 'ts', 'vob']):
							#print y[2]+' exception1'
							continue
						add_link('', name, '', url, '', name)		
				else:
					index=name.find(' - Fshare') 
					if index:
						name = name[:index] 
					print name
					y = name.rpartition('.')
					if (y[2] in ['jpg', 'png', 'txt', 'torrent', 'nfo', 'srt', 'sub', 'rar', 'zip', 'iso', 'ts', 'vob']):
						#print y[2]+' exception'
						continue

					add_link('', name, '', url, '', name)
		if page < gs.num_results-1:
			add_dir('Next>', '', 17, '', query, 'folder', page+1)
		print 'Search took %d' %(time.time()-start)
	except SearchError, e:
		print "Search failed: %s" % e

def add_fshareDir(name, url):
	print 'fetching '+url
	response = urlfetch.fetch(url)
	if response.status==302 and response.headers['location'].find('logout.php')<0:
		url=response.headers['location']
		response = urlfetch.fetch(url)
	rows = re.compile("<a class=\"filename\".+?href=\"(.+?)\".+?title=\"(.+?)\".+?file_size.+?>(.+?)<", re.DOTALL).findall(response.content)
	for item in rows:
		filename = decodeHtmlentities(item[1])
		y = filename.rpartition('.')
		#print y[0]
		#print y[1]
		#print y[2]
		if (y[2] in ['jpg', 'png', 'txt', 'torrent', 'nfo', 'srt', 'sub', 'rar', 'zip', 'iso']):
			#print y[2]+' exceptoon'
			continue
		#if filename.endswith('.jpg') or filename.endswith('.torrent') or filename:
		#	continue
		if (re.match('\.[0-9][0-9][0-9]$', filename)):
			continue
		if ' B' in item[2]:
			continue
		add_link('', filename+' '+item[2], '', item[0], '', item[1])
#def add_dir(name,url,mode,iconimage,query='',type='folder',page=0, thumbnailImage=''):

def playURL():
	query = common.getUserInput('Play Fshare URL', '') 

	if query is None:
		return
	query = re.sub(r'http:', r'https:', query)
	addPlayURL(query)

def search(url, query = '', type='hdrepo', page=0):
	if query is None or query=='':
		query = common.getUserInput('Search', '') 

	if query is None:
		return
	
	if saveSearch=='true':
		searchList = cache.get('searchList').split("\n")
		if not query in searchList:
			searchList.append(query)
			cache.set('searchList','\n'.join(searchList))
	try:
		response = urlfetch.fetch('https://script.google.com/macros/s/AKfycbw_O06k2mpeLxbpWGGKiEHkOLge-H5tbSXdRZt5mTVHJQthH74/exec?query='+urllib.quote_plus(query)+'&type='+type)
	except:
		pass

	if type == 'google':
		gsearch(query)
	elif type == 'vaphim':
		vaphimSearch(query, 0)
	else:
		hdrepo('search4', query)

def resolve_url(url):
	#print datetime.datetime.now().time()
	url = re.sub(r'http:', r'https:', url)
	headers['Cookie'] = doLogin()
	response = urlfetch.get(url,headers=headers, follow_redirects=True)
	print 'status1 '+str(response.status)
	if response.status==302 and response.headers['location'].find('logout.php')<0:
		url=response.headers['location']
		response = urlfetch.get(url, headers=headers, follow_redirects=True)
		# logout
	#print response.headers.get('set-cookie', '')
	if response.status == 200:
		items = re.compile('alert-danger', re.DOTALL).findall(response.content)
		if items:
			xbmc.executebuiltin(('XBMC.Notification("%s", "%s", %s)' % ('Fetching', 'Another device used your account', '5000')))
		#print response.content
		items = re.compile('data-linkcode=\"(.+?)\".+?value=\"([^\"]+?)\" name=\"fs_csrf\"', re.DOTALL).findall(response.content)
		#print 'resolve fs '+items[0]
		headers['Referer'] = url
		headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.2; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0'
		#print headers
		form_fields = {
			"fs_csrf" : items[0][1],
			"DownloadForm[pwd]":"",
			"DownloadForm[linkcode]":items[0][0],
			"ajax":"download-form",
			"undefined":"undefined"
		}

		form_data = urllib.urlencode(form_fields)
		#print form_data
		c=0
		while (c<3):
			time.sleep(3)
			response = urlfetch.fetch(
				url = 'https://www.fshare.vn/download/get',
				method='POST',
				headers = headers,
				data=form_data,
				follow_redirects = False
			)

			#response = urlfetch.get('https://www.fshare.vn/download/index', headers=headers, follow_redirects=True)
			#print 'content: '+response.content
			items = re.compile("\"url\":\"(.+?)\"", re.DOTALL).findall(response.content)
			if items:
				url = items[0].replace("\/", "/")
				break
			else:
				#print response.content
				url = ''
			c  = c+1
			print 'Retry: '+str(c)

		if url == '':
			xbmc.executebuiltin(('XBMC.Notification("%s", "%s", %s)' % ('Fetching', 'Content Not Found', '5000'))) 
			return
		'''
		items = re.compile('var\ url\ =\ \'(.+?)\'', re.DOTALL).findall(response.content)
		#print items
		if items:
			url = items[0]
		else:
			xbmc.executebuiltin(('XBMC.Notification("%s", "%s", %s)' % ('Fetching', 'Content Not Found', '5000'))) 
			return
		'''
	else:
		print 'weird error '+int(response.status)
		xbmc.executebuiltin(('XBMC.Notification("%s", "%s", %s)' % ('Login', 'Login failed. You must input correct FShare username/pass in Add-on settings', '5000'))) 
		return
	print url
	item = xbmcgui.ListItem(path=url)
	item.setProperty('IsPlayable', 'true')
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

	response = urlfetch.get('http://www.fshare.vn/logout.php', headers=headers).content
	#print response


def add_link(date, name, duration, href, thumb, desc):
	description = str(date)+'\n\n'+desc
	print href
	#print name
	u=sys.argv[0]+"?url="+urllib.quote_plus(href)+"&mode=4&name="+urllib.quote_plus(name)
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=thumb)
	liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "Duration": duration})
	liz.setProperty('IsPlayable', 'true')
	liz.addContextMenuItems([(u'Add to your library',u"XBMC.RunPlugin(%s?mode=%s&url=%s&query=%s) "%(sys.argv[0],15,href,urllib.quote_plus(name, safe='/')))])
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)

def add_dir(name,url,mode,iconimage,query='',type='folder',page=0, thumbnailImage=''):
	_url = re.sub('&amp;','$amp;',url)
	_query = re.sub('&amp;','$amp;',str(query))
	u=sys.argv[0]+"?url="+urllib.quote_plus(_url)+"&mode="+str(mode)+"&query="+urllib.quote_plus(_query)+"&type="+str(type)+"&page="+str(page)#+"&name="+urllib.quote_plus(name)
	print u
	ok=True
	liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name} )
	if mode == 21:
		liz.setProperty('IsPlayable', 'true')
	liz.setProperty('Fanart_Image', thumbnailImage) 
	if url == 'fshare_folder':
		liz.addContextMenuItems([('Add to your library',"XBMC.RunPlugin(%s?mode=%s&url=%s&query=%s) "%(sys.argv[0], 15, query, name))])
	if (type == 'fshare_folder'):
		liz.addContextMenuItems([('Add to your library',"XBMC.RunPlugin(%s?mode=%s&url=%s&query=%s) "%(sys.argv[0], 15, url, name))])
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def decodeHtmlentities(string):
	entity_re = re.compile(ur'&(#?)(\d{1,5}|\w{1,8});', re.UNICODE)

	def substitute_entity(match):
		from htmlentitydefs import name2codepoint as n2cp
		ent = match.group(2)
		if match.group(1) == "#":
			return unichr(int(ent)).encode('utf8')
		else:
			cp = n2cp.get(ent)

			if cp:
				return unichr(cp).encode('utf8')
			else:
				return match.group()

	return entity_re.subn(substitute_entity, string)[0]

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]

	return param

params=get_params()

url=''
name=None
mode=None
query=None
type='folder'
page=0

try:
	type=urllib.unquote_plus(params["type"])
except:
	pass
try:
	page=int(urllib.unquote_plus(params["page"]))
except:
	pass
try:
	query=re.sub('\$amp;','&', urllib.unquote_plus(params["query"]))
except:
	pass
try:
	url=re.sub('\$amp;','&', urllib.unquote_plus(params["url"]))
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass

if mode==10:
	__settings__.openSettings()
	mode=None

xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	
if mode==None:
	get_categories()

elif mode==1:
	searchMenu(url, '', type, page)
elif mode==2:
	search(url, query, type, page)
elif mode==3:
	clearSearch()
elif mode==4:
	try:
		urlfetch.fetch('https://script.google.com/macros/s/AKfycbw_O06k2mpeLxbpWGGKiEHkOLge-H5tbSXdRZt5mTVHJQthH74/exec?url='+params['url']+'&name='+params['name']+
			'&mid='+str(mid))
	except:
		pass
	resolve_url(url)
elif mode==9:
	searchMenu(url, '', 'file', page)
elif mode==10:
	__settings__.openSettings()
elif mode==12:
	hdrepo(url, str(query), str(page))
elif mode==13:
	sendLink(url)
elif mode==14:
	apple(url, str(query), str(page))
elif mode==15:
	addlib(url, query)
elif mode==16:
	add_fshareDir(name, url)
elif mode==17:
	gsearch(query, page)
elif mode == 20:
	fsrepo('', query, page)
elif mode == 21:
	playURL()
elif mode == 22:
	vaphimPage(url)
elif mode == 23:
	vaphimSearch(query, page)
elif mode == 24:
	vaphimXemNhieu()
elif mode == 25:
	vaphimCategory(url)
elif mode == 26:
	thiendia('', url, page)
elif mode == 27:
	thiendia_folder('', url, page)



xbmcplugin.endOfDirectory(int(sys.argv[1]))