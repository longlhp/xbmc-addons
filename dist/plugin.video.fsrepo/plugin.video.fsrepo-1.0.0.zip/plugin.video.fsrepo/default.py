import CommonFunctions as common
import urllib
import urllib2
import os
import xbmcplugin
import xbmcgui
import xbmcaddon
import urlfetch
import Cookie
from xgoogle.search import GoogleSearch, SearchError
import StorageServer
import re

try:
	import json
except:
	import simplejson as json

__settings__ = xbmcaddon.Addon(id='plugin.video.fsrepo')
__language__ = __settings__.getLocalizedString
home = __settings__.getAddonInfo('path')
icon = xbmc.translatePath( os.path.join( home, 'icon.png' ) )
saveSearch = 'false'
email = __settings__.getSetting('email')

#if saveSearch=='true':
cache = StorageServer.StorageServer("fshare3")

HTTP_DESKTOP_UA = {
	'Host':'www.fshare.vn',
	'Accept-Encoding':'gzip, deflate',
	'Referer':'https://www.fshare.vn/login.php',
	'Connection':'keep-alive',
	'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'User-Agent':'Mozilla/5.0 (Windows NT 6.2; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0'
}

searchList=[]
headers = HTTP_DESKTOP_UA

def _makeCookieHeader(cookie):
	cookieHeader = ""
	for value in cookie.values():
		cookieHeader += "%s=%s; " % (value.key, value.value)
	return cookieHeader

def doLogin():

	username = __settings__.getSetting('username')
	password = __settings__.getSetting('password')
	if (not username) or (not password):
		return False
	cookie = Cookie.SimpleCookie()
	
	form_fields = {
		"login_useremail":  username,
		"login_password":  password,
		"url_refe": "https://www.fshare.vn/index.php"
	}

	form_data = urllib.urlencode(form_fields)
	
	response = urlfetch.fetch(
		url = 'https://www.fshare.vn/login.php',
		method='POST',
		headers = headers,
		data=form_data,
		follow_redirects = False
	)

	cookie.load(response.headers.get('set-cookie', ''))
	headers['Cookie'] = _makeCookieHeader(cookie)
	print headers['Cookie']
	if headers['Cookie'].find('-1')>0:
		xbmc.executebuiltin((u'XBMC.Notification("%s", "%s", %s)' % ('Login', 'Login failed. You must input correct FShare username/pass in Add-on settings', '15')).encode("utf-8"))	 
		return False
	else:
		cache.set('cookie', headers['Cookie'])
		return headers['Cookie']
	
def make_request(url):
	headers = {
		'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'User-Agent':'Mozilla/5.0 (Windows NT 6.2; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0'
	}
	try:
		req = urllib2.Request(url,headers=headers)
		f = urllib2.urlopen(req)
		body=f.read()
		return body
	except urllib2.URLError, e:
		print 'We failed to open "%s".' % url
		if hasattr(e, 'reason'):
			print 'We failed to reach a server.'
			print 'Reason: ', e.reason
		if hasattr(e, 'code'):
			print 'We failed with error code - %s.' % e.code


def get_categories():
	if saveSearch=='true':
		add_dir('Search Google', '', 1, icon, query, 'google', 0)
		add_dir('Search HDrepo', '', 1, icon, query, 'hdrepo', 0)
	else:
		add_dir('Search Google', url, 2, icon, '', 'google', 0)
		add_dir('Search HDrepo', url, 2, icon, '', 'hdrepo', 0)
	#add_dir('Apple iTunes', 'apple_root', 14, icon, '', 'folder', 0)
	hdrepo('root','')

	add_dir('Add-on settings', '', 10, icon, query, type, 0)

def hdrepo(provider, param, start=0):

	if provider=='search':
		param = common.getUserInput('Search', '') 
		param = param.replace(' ', '%20')

	data = {'provider': provider, 'param': param, 'start': start}
	data = urllib.urlencode(data)
	result = json.load(urllib.urlopen('http://feed.hdrepo.com/v1/feed.php', data))
	for item in result:
		if item['type'] == 'fshare_folder':
			#add_dir(item['title'], item['param'], 5, item['thumb'])
			add_dir(item['title'], item['provider'], 12, item['thumb'], item['param'])
		else:
			if item['type'] == 'fshare_file' and item['title'] is not None:
				add_link(item['date'], item['title'], item['duration'], item['param'], item['thumb'], item['desc'])
			else:
				if item['type'] == 'folder':
					try:
						if 'start' in item:
							add_dir(item['title'], item['provider'], 12, item['thumb'], item['param'], '', item['start'])
						else:
							add_dir(item['title'], item['provider'], 12, item['thumb'], item['param'])
					except:
						pass

def apple(provider, param, start=0):
	if provider=='apple_root':
		add_dir('Genre', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/genres.json', 'folder', 0)
		add_dir('Action and Adventure', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/action_and_adventure.json', 'folder', 0)
		add_dir('Comedy', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/comedy.json', 'folder', 0)
		add_dir('Family', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/family.json', 'folder', 0)
		add_dir('Fantasy', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/fantasy.json', 'folder', 0)
		add_dir('Foreign', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/foreign.json', 'folder', 0)
		add_dir('Horror', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/horror.json', 'folder', 0)
		add_dir('Musical', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/musical.json', 'folder', 0)
		add_dir('Romance', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/romance.json', 'folder', 0)
		add_dir('Science Fiction', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/science_fiction.json', 'folder', 0)
		add_dir('Thriller', 'apple', 14, icon, 'http://trailers.apple.com/itunes/us/json/thriller.json', 'folder', 0)

	if provider=='apple':
		result = json.load(urllib.urlopen(param))
		if not 'data' in result:
			movies = result;
		else:
			movies = result['data'];
		for item in movies:
			if item.get('location') is None:
				add_dir(item['title'], 'search4', 12, 'http://trailers.apple.com/' + item['poster'], item['title'])
			else:
				add_dir(item['title'], 'search4', 12, 'http://trailers.apple.com/' + item['poster'], item['title'], thumbnailImage = 'http://trailers.apple.com' + item.get('location') + 'images/background.jpg')
			#print 'http://trailers.apple.com/' + item['location'] + 'images/background.jpg';

						
def sendLink(url):
	data = {'email': email, 'url': url}
	data = urllib.urlencode(data)
	try:
		response = urllib.urlopen('http://feed.hdrepo.com/sendlink.php', data)
		result = json.load(response)
		xbmc.executebuiltin((u'XBMC.Notification("%s", "%s", %s)' % ('Download link', result['message'], '5000')).encode("utf-8"))	 
	except:
		xbmc.executebuiltin((u'XBMC.Notification("%s", "%s", %s)' % ('Download link', 'Server only accepts 1 request/minute', '5000')).encode("utf-8"))	 

def clearstring(str):
	str = ''.join(e for e in str if e.isalnum() or e in '.-_ ()')
	return str
		
def addlib(url, name):
	print 'URL' + url
	id = url
	library_folder = __settings__.getSetting('library_folder')
	if library_folder == "":
		xbmc.executebuiltin((u'XBMC.Notification("%s", "%s", %s)' % ('Add to your library', 'You need to setup library folder in Add-on Setting', '5000')).encode("utf-8"))
		return

	if not os.path.exists(library_folder):
		os.makedirs(library_folder)		
		
	if '/file/' in url:
		filename = name
		
		k = filename.rfind("(")
		k = filename.rfind(".", 0, k)
		filename = filename[:k] + '.strm'
		
		target = open (library_folder + '/' + clearstring(filename), 'w')
		target.write('plugin://plugin.video.hdrepo/?mode=4&url=' + id)
		target.close()
		return
		
	if '/folder/' in url:
		data = {'provider': 'fshare_folder', 'param': url, 'start': 0}
		data = urllib.urlencode(data)
		result = json.load(urllib.urlopen('http://feed.hdrepo.com/v1/feed.php', data))
		
		library_folder = library_folder + '/' + clearstring(name)
		os.makedirs(library_folder)		
		
		for item in result:
			url = item['title']
			id = item['param']

			k = url.rfind("/")
			filename = url[k+1:]
			
			k = filename.rfind("(")
			k = filename.rfind(".", 0, k)
			filename = filename[:k] + '.strm'
			
			target = open (library_folder + '/' + clearstring(filename), 'w')
			target.write('plugin://plugin.video.hdrepo/?mode=4&url=' + id)
			target.close()
		return
		
def searchMenu(url, query = '', type='folder', page=0):
	add_dir('New Search', url, 2, icon, query, type, 0)
	add_dir('Clear Search', url, 3, icon, query, type, 0)

	searchList=cache.get('searchList').split("\n")
	for item in searchList:
		add_dir(item, url, 2, icon, item, type, 0)

def clearSearch():
	cache.set('searchList','')

def clearCache():
	cache.delete('http%')

def gsearch(query, page=0):
	print 'gsearch called '+query+' page='+str(page)
	try:
		gs = GoogleSearch("site:fshare.vn " +query)
		gs.page = page
		gs.results_per_page = 50
		results = gs.get_results()
		for res in results:
			name = res.title.encode("utf8")
			url = res.url.encode("utf8") 
			if 'folder' in res.url:
				#name = '>'+name
				add_dir(name+'>', url, 16, icon)
				#add_fshareDir(name, res.url.encode('utf8'))
			else:
				print 'name='+name+" "+url+" "
				if name.startswith('Fshare - Dich vu chia se'):
					print 'no name from google search so fetch from fshare'
					response = urlfetch.fetch(url)
					#print response.content
					regterm = u'T\u00EAn\ t\u1EADp\ tin:</b>\s(.+?)</p>.+?</b>\s(.+?)</p>'.encode('utf8')
					#print regterm
					item = re.findall(regterm, response.content, re.DOTALL|re.MULTILINE)
					print item
					if (item):
						name = item[0][0]+' '+item[0][1]
						add_link('', name, '', url, icon, name)		
				else:
					add_link('', name, '', url, icon, name)
		if page < gs.num_results-1:
			add_dir('Next>', '', 17, '', query, 'folder', page+1)
	except SearchError, e:
		print "Search failed: %s" % e

def add_fshareDir(name, url):
	print 'fetching '+url
	response = urlfetch.fetch(url)
	#print response.content
	rows = re.compile("\"w_80pc\"><a href=\"(.+?)\".+?class=\"filename\">(.+?)</span>.+?\"filesize\">(.+?)</span>", re.DOTALL).findall(response.content)
	for item in rows:
		filename = item[1]
		y = filename.rpartition('.')
		print y[0]
		print y[1]
		print y[2]
		if (y[2] in ['jpg', 'png', 'txt', 'torrent', 'nfo', 'srt', 'sub', 'rar', 'zip']):
			print y[2]+' exceptoon'
			continue
		#if filename.endswith('.jpg') or filename.endswith('.torrent') or filename:
		#	continue
		if (re.match('\.[0-9][0-9][0-9]$', filename)):
			continue
		add_link('', filename+' '+item[2], '', item[0], icon, item[1])
#def add_dir(name,url,mode,iconimage,query='',type='folder',page=0, thumbnailImage=''):


def search(url, query = '', type='hdrepo', page=0):
	if query is None or query=='':
		query = common.getUserInput('Search', '') 

	if query is None:
		return
	
	if saveSearch=='true':
		searchList = cache.get('searchList').split("\n")
		if not query in searchList:
			searchList.append(query)
			cache.set('searchList','\n'.join(searchList))
	if type == 'google':
		gsearch(query)
	else:
		hdrepo('search4', query)

def resolve_url(url):
	headers['Cookie'] = doLogin()
	print url
	response = urlfetch.get(url,headers=headers, follow_redirects=False)
	if response.status==302 and response.headers['location'].find('logout.php')<0:
		url=response.headers['location']
		# logout
	else:
		if response.status==200:
			#print response.content
			errors = re.compile('<ul\ class=\"message-error\">.+?<li>(.+?)</li>', re.DOTALL).findall(response.content)
			if errors:
				print errors
				xbmc.executebuiltin((u'XBMC.Notification("%s", "%s", %s)' % ('Fshare', errors[0][0], '5000')).encode("utf-8"))	 
				return
			items = re.compile('<form action=\"(.+?)\".+?name=\"frm_download\">.+?name=\"file_id\"\ value=\"(.+?)\"', re.DOTALL).findall(response.content)
			#print items
			if items:
				frm = items[0][0]
				if frm == '#download':
					print 'try to fetch second time'
					form_fields = {
						"action": 'download_file',
						"file_id": items[0][1],
						"special": ''
					}

					form_data = urllib.urlencode(form_fields)
					import time
					time.sleep(10)
					print 'sleep and post second time'
					response = urlfetch.fetch(
						url = url,
						method='POST',
						headers = headers,
						data=form_data,
						follow_redirects = False
					)
					#print response.content
					errors = re.compile('<ul\ class=\"message-error\">.+?<li>(.+?)</li>', re.DOTALL).findall(response.content)
					if errors:
						print errors[0]
						xbmc.executebuiltin(('XBMC.Notification("%s", "%s", %s)' % ('Fshare error', errors[0], '5000')))	 
						return

					items = re.compile('<form action=\"(.+?)\".+?name=\"frm_download\">', re.DOTALL).findall(response.content)
					if items:
						url = items[0]
						print url
		else:
			print 'weird error '+response.status
			xbmc.executebuiltin(('XBMC.Notification("%s", "%s", %s)' % ('Login', 'Login failed. You must input correct FShare username/pass in Add-on settings', '5000'))) 
			return
	print url
	item = xbmcgui.ListItem(path=url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

	response = urlfetch.get('http://www.fshare.vn/logout.php', headers=headers).content
	#print response

def add_link(date, name, duration, href, thumb, desc):
	description = date+'\n\n'+desc
	u=sys.argv[0]+"?url="+urllib.quote_plus(href)+"&mode=4"
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=thumb)
	liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "Duration": duration})
	liz.setProperty('IsPlayable', 'true')
	if email != '' and freeAccount == 'true':
		liz.addContextMenuItems([('Send download link',"XBMC.RunPlugin(%s?mode=%s&url=%s) "%(sys.argv[0],13,href))])
	liz.addContextMenuItems([('Add to your library',"XBMC.RunPlugin(%s?mode=%s&url=%s&query=%s) "%(sys.argv[0],15,href,name))])
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)

def add_dir(name,url,mode,iconimage,query='',type='folder',page=0, thumbnailImage=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&query="+str(query)+"&type="+str(type)+"&page="+str(page)#+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name} )
	liz.setProperty('Fanart_Image', thumbnailImage) 
	if url == 'fshare_folder':
		liz.addContextMenuItems([('Add to your library',"XBMC.RunPlugin(%s?mode=%s&url=%s&query=%s) "%(sys.argv[0], 15, query, name))])
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok


def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]

	return param

params=get_params()

url=''
name=None
mode=None
query=None
type='folder'
page=0

try:
	type=urllib.unquote_plus(params["type"])
except:
	pass
try:
	page=int(urllib.unquote_plus(params["page"]))
except:
	pass
try:
	query=urllib.unquote_plus(params["query"])
except:
	pass
try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass

if mode==10:
	__settings__.openSettings()
	mode=None

xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	
if mode==None:
	get_categories()

elif mode==1:
	searchMenu(url, '', type, page)
elif mode==2:
	search(url, query, type, page)
elif mode==3:
	clearSearch()
elif mode==4:
	resolve_url(url)
elif mode==9:
	searchMenu(url, '', 'file', page)
elif mode==10:
	__settings__.openSettings()
elif mode==12:
	hdrepo(url, str(query), str(page))
elif mode==13:
	sendLink(url)
elif mode==14:
	apple(url, str(query), str(page))
elif mode==15:
	addlib(url, query)
elif mode==16:
	add_fshareDir(name, url)
elif mode==17:
	gsearch(query, page)

xbmcplugin.endOfDirectory(int(sys.argv[1]))